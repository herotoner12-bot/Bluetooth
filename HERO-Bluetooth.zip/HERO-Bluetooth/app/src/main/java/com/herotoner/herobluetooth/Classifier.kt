package com.herotoner.herobluetooth

enum class Cat(val label: String) {
    HEADPHONES("سماعات"),
    SPEAKER("مكبرات صوت"),
    KEYBOARD("لوحات مفاتيح"),
    MOUSE("فأرة"),
    OTHER("أجهزة أخرى")
}

/** تصنيف الجهاز من BluetoothClass الحقيقي (بلا تخمين): الثوابت مطابقة لـ android.bluetooth.BluetoothClass. */
object Classifier {
    const val MAJOR_AUDIO_VIDEO = 0x0400
    const val MAJOR_PERIPHERAL = 0x0500

    fun categorize(major: Int, deviceClass: Int): Cat {
        if (major == MAJOR_AUDIO_VIDEO) {
            return when (deviceClass) {
                0x0404, 0x0408, 0x0418 -> Cat.HEADPHONES // headset, handsfree, headphones
                0x0414, 0x041C, 0x0420, 0x0428 -> Cat.SPEAKER // loudspeaker, portable, car, hi-fi
                else -> Cat.OTHER
            }
        }
        if (major == MAJOR_PERIPHERAL) {
            val keyboard = (deviceClass and 0x40) != 0
            val pointing = (deviceClass and 0x80) != 0
            return when {
                keyboard -> Cat.KEYBOARD
                pointing -> Cat.MOUSE
                else -> Cat.OTHER
            }
        }
        return Cat.OTHER
    }
}
