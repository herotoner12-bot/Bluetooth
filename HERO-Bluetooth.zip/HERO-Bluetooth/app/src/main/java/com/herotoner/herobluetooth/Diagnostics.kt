package com.herotoner.herobluetooth

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings

enum class Status { OK, WARN, BAD, UNKNOWN }

data class Check(
    val title: String,
    val value: String,
    val status: Status,
    val detail: String = ""
)

class Report(
    val checks: List<Check>,
    val verdict: String,
    val verdictStatus: Status,
    val adapterPresent: Boolean,
    val enabled: Boolean,
    val permsGranted: Boolean
) {
    val canConnect: Boolean get() = adapterPresent && enabled && permsGranted
}

object Diagnostics {

    fun requiredPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= 31) {
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }

    fun hasPermissions(ctx: Context): Boolean =
        requiredPermissions().all {
            ctx.checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED
        }

    private fun <T> safe(block: () -> T): T? =
        try {
            block()
        } catch (e: Throwable) {
            null
        }

    fun adapterOf(ctx: Context): BluetoothAdapter? =
        safe { (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter }

    @Suppress("DEPRECATION")
    fun run(ctx: Context): Report {
        val pm = ctx.packageManager
        val featBt = safe { pm.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH) } ?: false
        val featLe = safe { pm.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE) } ?: false
        val manager = safe { ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager }
        val adapter: BluetoothAdapter? = safe { manager?.adapter }
        val stackPkg = listOf("com.android.bluetooth", "com.google.android.bluetooth")
            .any { p -> safe { pm.getPackageInfo(p, 0) } != null }
        val settingsExists = safe {
            pm.resolveActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS), 0) != null
        } ?: false
        val globalFlag = safe { Settings.Global.getInt(ctx.contentResolver, "bluetooth_on") }
        val state = safe { adapter?.state }
        val enabled = state == BluetoothAdapter.STATE_ON
        val perms = hasPermissions(ctx)
        val present = adapter != null

        val checks = mutableListOf<Check>()

        checks += if (present) {
            Check("Bluetooth Adapter", "موجود", Status.OK, "أعاد النظام محوّل Bluetooth فعلياً.")
        } else {
            Check("Bluetooth Adapter", "غير موجود", Status.BAD,
                "لم يُرجع النظام أي محوّل Bluetooth (BluetoothAdapter = null).")
        }

        checks += if (manager != null) {
            Check("Bluetooth Manager", "موجود", Status.OK)
        } else {
            Check("Bluetooth Manager", "غير موجود", Status.BAD,
                "خدمة BluetoothManager غير متوفرة في هذا النظام.")
        }

        checks += when {
            present && featBt -> Check("Bluetooth Hardware", "مُعلَن من النظام", Status.OK,
                "النظام يصرّح بوجود Bluetooth. التطبيق لا يستطيع فحص الشريحة نفسها، فهذا إعلان من النظام وليس قياساً مباشراً.")
            else -> Check("Bluetooth Hardware", "غير معروف", Status.UNKNOWN,
                "تعذّر التأكد. قد يكون العتاد غير موجود أو معطّلاً من الشركة المصنّعة، والتطبيق لا يستطيع التفريق بين الحالتين.")
        }

        checks += when {
            present -> Check("Bluetooth Service", "متاحة", Status.OK)
            else -> Check("Bluetooth Service", "غير متاحة", Status.BAD,
                if (manager != null) "الخدمة موجودة لكنها لا تُرجع محوّلاً." else "")
        }

        checks += if (stackPkg) {
            Check("Bluetooth System Package", "موجودة", Status.OK, "حزمة Bluetooth الخاصة بالنظام مثبّتة.")
        } else {
            Check("Bluetooth System Package", "غير ظاهرة", Status.UNKNOWN,
                "لم تظهر حزمة Bluetooth للتطبيق. قد تكون محجوبة أو غير موجودة.")
        }

        checks += if (featLe) {
            Check("Bluetooth LE", "مدعوم", Status.OK)
        } else {
            Check("Bluetooth LE", "غير مدعوم", Status.BAD)
        }

        checks += when {
            !present -> Check("حالة Bluetooth", "غير مدعوم", Status.BAD)
            enabled -> Check("حالة Bluetooth", "مفعّل", Status.OK)
            state == BluetoothAdapter.STATE_OFF -> Check("حالة Bluetooth", "غير مفعّل", Status.WARN,
                "الإعداد العام للنظام: " + when (globalFlag) { 1 -> "مفعّل"; 0 -> "مطفأ"; else -> "غير معروف" })
            else -> Check("حالة Bluetooth", "قيد التبديل / غير معروف", Status.WARN)
        }

        checks += if (settingsExists) {
            Check("شاشة إعدادات Bluetooth", "موجودة", Status.OK)
        } else {
            Check("شاشة إعدادات Bluetooth", "غير موجودة", Status.WARN,
                "هذا التلفزيون لا يوفر شاشة إعدادات Bluetooth، وهذا مؤشر شائع على أن الميزة معطّلة من الشركة.")
        }

        checks += if (perms) {
            Check("صلاحيات Bluetooth", "ممنوحة", Status.OK)
        } else {
            Check("صلاحيات Bluetooth", "غير ممنوحة", Status.WARN, "مطلوبة للبحث والاقتران.")
        }

        val canConnect = present && enabled && perms
        checks += if (canConnect) {
            Check("إمكانية توصيل الأجهزة", "متاحة", Status.OK)
        } else {
            val why = when {
                !present -> "لا يوجد محوّل Bluetooth."
                !enabled -> "Bluetooth غير مفعّل."
                else -> "الصلاحيات غير ممنوحة."
            }
            Check("إمكانية توصيل الأجهزة", "غير متاحة", Status.BAD, why)
        }

        val (verdict, vStatus) = when {
            !present && !featBt -> Pair(
                "لم يجد التطبيق أي Bluetooth في النظام. غالباً العتاد غير موجود أو معطّل من الشركة، ولا يمكن لأي تطبيق إضافته برمجياً. إن أردت Bluetooth فقد تحتاج قطعة خارجية، ونجاحها يعتمد على دعم التلفزيون لها.",
                Status.BAD)
            !present -> Pair(
                "النظام يعلن دعم Bluetooth لكنه لا يعطي أي تطبيق محوّلاً. المشكلة على الأرجح في النظام أو الخدمة وليست في تطبيقك.",
                Status.WARN)
            !enabled -> Pair(
                "Bluetooth موجود في النظام لكنه غير مفعّل. فعّله من الزر ثم أعد الفحص.",
                Status.WARN)
            !perms -> Pair(
                "Bluetooth مفعّل. امنح الصلاحيات ليعمل البحث والاقتران.",
                Status.WARN)
            else -> Pair(
                "Bluetooth يعمل ويمكنك البحث عن الأجهزة واقترانها.",
                Status.OK)
        }

        return Report(checks, verdict, vStatus, present, enabled, perms)
    }
}
