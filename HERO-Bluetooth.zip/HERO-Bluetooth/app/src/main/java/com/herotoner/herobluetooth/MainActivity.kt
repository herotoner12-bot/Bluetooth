package com.herotoner.herobluetooth

import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private enum class Screen { REPORT, SCAN, BONDED }

    private class Found(
        val address: String,
        var name: String?,
        var cat: Cat,
        var bonded: Boolean,
        var rssi: Int
    )

    private val cBg = Color.parseColor("#101820")
    private val cPrimary = Color.parseColor("#19C37D")
    private val cCard = Color.parseColor("#1D2A31")
    private val cWhite = Color.WHITE
    private val cSub = Color.parseColor("#A8B8C1")
    private val cWarn = Color.parseColor("#F5B73D")
    private val cBad = Color.parseColor("#E5534B")

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var content: LinearLayout
    private var adapter: BluetoothAdapter? = null
    private var report: Report? = null
    private var screen = Screen.REPORT
    private var filter: Cat? = null
    private var scanning = false
    private var pendingScan = false
    private var receiverRegistered = false
    private var a2dp: Set<String> = emptySet()
    private val found = LinkedHashMap<String, Found>()

    // ---------- دورة الحياة ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            buildUi()
            runDiagnostics()
            if (adapter != null && !Diagnostics.hasPermissions(this)) {
                requestPermissions(Diagnostics.requiredPermissions(), 1)
            }
        } catch (e: Throwable) {
            showFatal(e)
        }
    }

    override fun onStart() {
        super.onStart()
        try {
            val f = IntentFilter().apply {
                addAction(BluetoothDevice.ACTION_FOUND)
                addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED)
                addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
            }
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(receiver, f, Context.RECEIVER_EXPORTED)
            } else {
                registerReceiver(receiver, f)
            }
            receiverRegistered = true
        } catch (e: Throwable) {
            receiverRegistered = false
        }
    }

    override fun onStop() {
        super.onStop()
        stopScan()
        if (receiverRegistered) {
            try { unregisterReceiver(receiver) } catch (e: Throwable) { }
            receiverRegistered = false
        }
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        try {
            runDiagnostics()
            if (pendingScan && Diagnostics.hasPermissions(this)) {
                pendingScan = false
                startScan()
            } else if (!Diagnostics.hasPermissions(this)) {
                toast("بدون صلاحيات Bluetooth لا يمكن البحث أو الاقتران.")
            }
        } catch (e: Throwable) {
            toast("حدث خطأ: ${e.message}")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        try { runDiagnostics() } catch (e: Throwable) { toast("حدث خطأ: ${e.message}") }
    }

    // ---------- الاستقبال ----------

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            try {
                when (i.action) {
                    BluetoothDevice.ACTION_FOUND -> {
                        val d = i.device() ?: return
                        val rssi = i.getShortExtra(BluetoothDevice.EXTRA_RSSI, Short.MIN_VALUE).toInt()
                        addDevice(d, rssi, null)
                    }
                    BluetoothDevice.ACTION_BOND_STATE_CHANGED -> {
                        val d = i.device() ?: return
                        val st = i.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, BluetoothDevice.ERROR)
                        found[d.address]?.bonded = (st == BluetoothDevice.BOND_BONDED)
                        when (st) {
                            BluetoothDevice.BOND_BONDED -> toast("تم الاقتران بنجاح.")
                            BluetoothDevice.BOND_NONE -> toast("لم يتم الاقتران (فشل أو رفض).")
                        }
                        refreshIfVisible()
                    }
                    BluetoothAdapter.ACTION_STATE_CHANGED -> {
                        runDiagnostics()
                    }
                }
            } catch (e: Throwable) {
                // لا نُغلق التطبيق بسبب حدث واحد
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun Intent.device(): BluetoothDevice? =
        if (Build.VERSION.SDK_INT >= 33) {
            getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
        } else {
            getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
        }

    private val leCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            try { addDevice(result.device, result.rssi, result.scanRecord?.deviceName) } catch (e: Throwable) { }
        }

        override fun onScanFailed(errorCode: Int) {
            // البحث الكلاسيكي يستمر؛ لا حاجة لإزعاج المستخدم
        }
    }

    private val stopRunnable = Runnable {
        stopScan()
        render()
    }

    private val renderRunnable = Runnable {
        if (screen == Screen.SCAN && (!content.hasFocus() || !scanning)) render()
    }

    // ---------- الفحص ----------

    private fun runDiagnostics() {
        adapter = Diagnostics.adapterOf(this)
        report = Diagnostics.run(this)
        if (screen == Screen.REPORT) render()
    }

    // ---------- البحث والاقتران ----------

    private fun startScan() {
        val a = adapter
        if (a == null) {
            screen = Screen.REPORT
            render()
            toast("لا يوجد محوّل Bluetooth في هذا التلفزيون.")
            return
        }
        if (!Diagnostics.hasPermissions(this)) {
            pendingScan = true
            requestPermissions(Diagnostics.requiredPermissions(), 1)
            return
        }
        if (a.state != BluetoothAdapter.STATE_ON) {
            toast("فعّل Bluetooth أولاً.")
            requestEnable()
            return
        }
        found.clear()
        try {
            for (d in a.bondedDevices) {
                found[d.address] = Found(d.address, d.name, categorize(d), true, Int.MIN_VALUE)
            }
        } catch (e: Throwable) { }
        screen = Screen.SCAN
        scanning = true
        try { a.cancelDiscovery() } catch (e: Throwable) { }
        try { a.startDiscovery() } catch (e: Throwable) { toast("تعذّر بدء البحث: ${e.message}") }
        try {
            if (packageManager.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
                a.bluetoothLeScanner?.startScan(leCallback)
            }
        } catch (e: Throwable) { }
        ui.removeCallbacks(stopRunnable)
        ui.postDelayed(stopRunnable, 15000)
        render()
    }

    private fun stopScan() {
        ui.removeCallbacks(stopRunnable)
        try { adapter?.cancelDiscovery() } catch (e: Throwable) { }
        try { adapter?.bluetoothLeScanner?.stopScan(leCallback) } catch (e: Throwable) { }
        scanning = false
    }

    private fun categorize(d: BluetoothDevice): Cat {
        return try {
            val c = d.bluetoothClass ?: return Cat.OTHER
            Classifier.categorize(c.majorDeviceClass, c.deviceClass)
        } catch (e: Throwable) {
            Cat.OTHER
        }
    }

    private fun addDevice(d: BluetoothDevice, rssi: Int, leName: String?) {
        val addr = d.address ?: return
        val name = try { d.name } catch (e: Throwable) { null } ?: leName
        val cat = categorize(d)
        val bonded = try { d.bondState == BluetoothDevice.BOND_BONDED } catch (e: Throwable) { false }
        val ex = found[addr]
        if (ex == null) {
            found[addr] = Found(addr, name, cat, bonded, rssi)
        } else {
            if (ex.name == null) ex.name = name
            if (ex.cat == Cat.OTHER) ex.cat = cat
            if (rssi != Int.MIN_VALUE && rssi != Short.MIN_VALUE.toInt()) ex.rssi = rssi
            ex.bonded = bonded
        }
        ui.removeCallbacks(renderRunnable)
        ui.postDelayed(renderRunnable, 500)
    }

    private fun onDeviceClick(f: Found) {
        val a = adapter ?: return
        try {
            val d = a.getRemoteDevice(f.address)
            when (d.bondState) {
                BluetoothDevice.BOND_BONDED -> showBondedInfo(f)
                BluetoothDevice.BOND_BONDING -> toast("الاقتران جارٍ، انتظر.")
                else -> {
                    try { a.cancelDiscovery() } catch (e: Throwable) { }
                    if (d.createBond()) {
                        toast("بدأ الاقتران. إن ظهر طلب تأكيد أو رمز فوافق عليه.")
                    } else {
                        toast("رفض النظام طلب الاقتران.")
                    }
                }
            }
        } catch (e: SecurityException) {
            toast("الصلاحية مفقودة. امنح صلاحيات Bluetooth.")
        } catch (e: Throwable) {
            toast("تعذّر الاقتران: ${e.message}")
        }
    }

    private fun showBondedInfo(f: Found) {
        val msg = "الجهاز مقترن مع التلفزيون.\n\nلا يوفر Android لتطبيقات الطرف الثالث واجهة رسمية لوصل أو فصل أجهزة الإدخال والصوت؛ يتصل النظام بها تلقائياً عند تشغيل الجهاز. لإلغاء الاقتران أو التحكم به استخدم إعدادات Bluetooth في النظام."
        AlertDialog.Builder(this)
            .setTitle(f.name ?: f.address)
            .setMessage(msg)
            .setPositiveButton("إعدادات Bluetooth") { _, _ -> openSystemSettings() }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    private fun requestEnable() {
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), 77)
        } catch (e: Throwable) {
            toast("تعذّر طلب التفعيل من التطبيق. جرّب إعدادات Bluetooth في النظام.")
            openSystemSettings()
        }
    }

    private fun openSystemSettings() {
        try {
            val i = Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            if (i.resolveActivity(packageManager) != null) {
                startActivity(i)
            } else {
                toast("هذا التلفزيون لا يوفر شاشة إعدادات Bluetooth.")
            }
        } catch (e: Throwable) {
            toast("تعذّر فتح إعدادات Bluetooth.")
        }
    }

    private fun loadA2dp() {
        val a = adapter ?: return
        try {
            a.getProfileProxy(this, object : BluetoothProfile.ServiceListener {
                override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                    try { a2dp = proxy.connectedDevices.map { it.address }.toSet() } catch (e: Throwable) { }
                    try { a.closeProfileProxy(profile, proxy) } catch (e: Throwable) { }
                    runOnUiThread { if (screen == Screen.BONDED) render() }
                }

                override fun onServiceDisconnected(profile: Int) {}
            }, BluetoothProfile.A2DP)
        } catch (e: Throwable) { }
    }

    // ---------- الواجهة ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) {
        try { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() } catch (e: Throwable) { }
    }

    private fun lp(w: Int, h: Int, top: Int = 0, weight: Float = 0f): LinearLayout.LayoutParams {
        val p = if (weight > 0f) LinearLayout.LayoutParams(w, h, weight) else LinearLayout.LayoutParams(w, h)
        p.topMargin = top
        return p
    }

    private fun roundBg(fill: Int, stroke: Int, strokeDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(14).toFloat()
            setStroke(dp(strokeDp), stroke)
        }

    private fun focusFill(fill: Int): StateListDrawable = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_focused), roundBg(cPrimary, cWhite, 3))
        addState(intArrayOf(android.R.attr.state_pressed), roundBg(cPrimary, cWhite, 3))
        addState(intArrayOf(), roundBg(fill, Color.TRANSPARENT, 0))
    }

    private fun focusStroke(fill: Int): StateListDrawable = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_focused), roundBg(fill, cPrimary, 3))
        addState(intArrayOf(), roundBg(fill, Color.TRANSPARENT, 0))
    }

    private fun flipText(): ColorStateList = ColorStateList(
        arrayOf(
            intArrayOf(android.R.attr.state_focused),
            intArrayOf(android.R.attr.state_pressed),
            intArrayOf()
        ),
        intArrayOf(cBg, cBg, cWhite)
    )

    private fun tv(text: String, sp: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = sp
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun btn(text: String, sp: Float = 20f, onClick: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            setAllCaps(false)
            textSize = sp
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(flipText())
            background = focusFill(cCard)
            gravity = Gravity.CENTER_VERTICAL or Gravity.START
            setPadding(dp(20), dp(8), dp(20), dp(8))
            isFocusable = true
            setOnClickListener {
                try { onClick() } catch (e: Throwable) { toast("حدث خطأ: ${e.message}") }
            }
        }

    private fun statusColor(s: Status): Int = when (s) {
        Status.OK -> cPrimary
        Status.WARN -> cWarn
        Status.BAD -> cBad
        Status.UNKNOWN -> cSub
    }

    private fun statusMark(s: Status): String = when (s) {
        Status.OK -> "✔ "
        Status.WARN -> "! "
        Status.BAD -> "✖ "
        Status.UNKNOWN -> "؟ "
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(cBg)
            setPadding(dp(32), dp(24), dp(32), dp(24))
        }

        val menu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(dp(330), MATCH)
        }
        val logo = ImageView(this).apply { setImageResource(R.drawable.ic_logo) }
        menu.addView(logo, LinearLayout.LayoutParams(dp(96), dp(96)))
        menu.addView(tv("HERO Bluetooth", 30f, cWhite, true), lp(WRAP, WRAP, dp(8)))
        menu.addView(tv("فحص Bluetooth التلفزيون", 16f, cSub), lp(WRAP, WRAP, dp(2)))

        val first = btn("فحص النظام") { screen = Screen.REPORT; runDiagnostics(); render() }
        menu.addView(first, lp(MATCH, dp(60), dp(24)))
        menu.addView(btn("البحث عن الأجهزة") { startScan() }, lp(MATCH, dp(60), dp(12)))
        menu.addView(btn("الأجهزة المقترنة") {
            stopScan()
            screen = Screen.BONDED
            loadA2dp()
            render()
        }, lp(MATCH, dp(60), dp(12)))
        menu.addView(btn("تفعيل Bluetooth") { requestEnable() }, lp(MATCH, dp(60), dp(12)))
        menu.addView(btn("إعدادات Bluetooth للنظام") { openSystemSettings() }, lp(MATCH, dp(60), dp(12)))

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), 0, dp(32), dp(24))
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(content, ViewGroup.LayoutParams(MATCH, WRAP))
        }

        root.addView(menu)
        root.addView(scroll, LinearLayout.LayoutParams(0, MATCH, 1f))
        setContentView(root)
        first.requestFocus()
    }

    private fun showFatal(e: Throwable) {
        val t = tv("تعذّر تشغيل الواجهة بالكامل:\n${e.message}\n\nأعد فتح التطبيق.", 22f, cWhite)
        t.setPadding(dp(32), dp(32), dp(32), dp(32))
        t.setBackgroundColor(cBg)
        setContentView(t)
    }

    private fun refreshIfVisible() {
        if (screen != Screen.REPORT) render()
    }

    private fun render() {
        try {
            content.removeAllViews()
            when (screen) {
                Screen.REPORT -> renderReport()
                Screen.SCAN -> renderScan()
                Screen.BONDED -> renderBonded()
            }
        } catch (e: Throwable) {
            content.removeAllViews()
            content.addView(tv("تعذّر عرض الشاشة: ${e.message}", 18f, cBad))
        }
    }

    private fun renderReport() {
        val r = report ?: return
        content.addView(tv("تقرير الفحص", 28f, cWhite, true))

        val verdict = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundBg(cCard, statusColor(r.verdictStatus), 3)
            setPadding(dp(20), dp(16), dp(20), dp(16))
        }
        verdict.addView(tv(r.verdict, 19f, cWhite))
        content.addView(verdict, lp(MATCH, WRAP, dp(16)))

        for (c in r.checks) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = focusStroke(cCard)
                isFocusable = true
                setPadding(dp(20), dp(12), dp(20), dp(12))
            }
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(tv(c.title, 20f, cWhite, true), LinearLayout.LayoutParams(0, WRAP, 1f))
            row.addView(tv(statusMark(c.status) + c.value, 20f, statusColor(c.status), true))
            card.addView(row)
            if (c.detail.isNotEmpty()) card.addView(tv(c.detail, 16f, cSub), lp(MATCH, WRAP, dp(4)))
            content.addView(card, lp(MATCH, WRAP, dp(10)))
        }

        val note = tv(
            "ملاحظة: عمل ريموت التلفزيون لا يثبت أن Bluetooth متاح للتطبيقات؛ فقد يعمل الريموت بالأشعة تحت الحمراء أو بتقنية أخرى.",
            15f, cSub
        )
        content.addView(note, lp(MATCH, WRAP, dp(16)))
    }

    private fun renderScan() {
        content.addView(tv("البحث عن الأجهزة", 28f, cWhite, true))

        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun chip(label: String, cat: Cat?) {
            val b = btn(label, 16f) { filter = cat; render() }
            if (filter == cat) b.background = roundBg(cCard, cPrimary, 3)
            chips.addView(b, LinearLayout.LayoutParams(WRAP, dp(48)).apply { marginEnd = dp(8) })
        }
        chip("الكل", null)
        chip("سماعات", Cat.HEADPHONES)
        chip("مكبرات", Cat.SPEAKER)
        chip("لوحات مفاتيح", Cat.KEYBOARD)
        chip("فأرة", Cat.MOUSE)
        val hs = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(chips)
        }
        content.addView(hs, lp(MATCH, WRAP, dp(12)))

        val list = found.values
            .filter { filter == null || it.cat == filter }
            .sortedWith(compareByDescending<Found> { it.bonded }.thenByDescending { it.rssi })

        val status = if (scanning) "جارٍ البحث… (${list.size})" else "اكتمل البحث: ${list.size} جهاز"
        content.addView(tv(status, 17f, cSub), lp(WRAP, WRAP, dp(12)))

        if (list.isEmpty()) {
            content.addView(
                tv("لا توجد أجهزة بعد. ضع الجهاز في وضع الاقتران (Pairing) وأعد البحث.", 18f, cWhite),
                lp(MATCH, WRAP, dp(12))
            )
        }
        for (f in list) {
            val sig = if (f.rssi != Int.MIN_VALUE) " • ${f.rssi} dBm" else ""
            val text = (f.name ?: "جهاز بدون اسم") + "\n" +
                f.cat.label + " • " + (if (f.bonded) "مقترن" else "غير مقترن") + " • " + f.address + sig
            content.addView(btn(text, 18f) { onDeviceClick(f) }, lp(MATCH, WRAP, dp(10)))
        }
    }

    private fun renderBonded() {
        content.addView(tv("الأجهزة المقترنة", 28f, cWhite, true))
        val a = adapter
        if (a == null) {
            content.addView(tv("لا يوجد محوّل Bluetooth في هذا التلفزيون.", 19f, cBad), lp(MATCH, WRAP, dp(16)))
            return
        }
        val devices = try { a.bondedDevices.toList() } catch (e: Throwable) { null }
        if (devices == null) {
            content.addView(
                tv("تعذّر قراءة الأجهزة المقترنة. امنح صلاحيات Bluetooth ثم أعد المحاولة.", 19f, cWarn),
                lp(MATCH, WRAP, dp(16))
            )
            return
        }
        if (devices.isEmpty()) {
            content.addView(tv("لا توجد أجهزة مقترنة.", 19f, cWhite), lp(MATCH, WRAP, dp(16)))
            return
        }
        for (d in devices) {
            val f = Found(d.address, try { d.name } catch (e: Throwable) { null }, categorize(d), true, Int.MIN_VALUE)
            val conn = if (a2dp.contains(d.address)) " • متصل (صوت)" else ""
            val text = (f.name ?: "جهاز بدون اسم") + "\n" + f.cat.label + " • " + d.address + conn
            content.addView(btn(text, 18f) { showBondedInfo(f) }, lp(MATCH, WRAP, dp(10)))
        }
    }
}
