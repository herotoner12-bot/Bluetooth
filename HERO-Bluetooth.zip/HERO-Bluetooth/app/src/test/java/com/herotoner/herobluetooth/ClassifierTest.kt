package com.herotoner.herobluetooth

import org.junit.Assert.assertEquals
import org.junit.Test

class ClassifierTest {
    @Test fun headphones() = assertEquals(Cat.HEADPHONES, Classifier.categorize(0x0400, 0x0418))
    @Test fun headset() = assertEquals(Cat.HEADPHONES, Classifier.categorize(0x0400, 0x0404))
    @Test fun speaker() = assertEquals(Cat.SPEAKER, Classifier.categorize(0x0400, 0x0414))
    @Test fun keyboard() = assertEquals(Cat.KEYBOARD, Classifier.categorize(0x0500, 0x0540))
    @Test fun mouse() = assertEquals(Cat.MOUSE, Classifier.categorize(0x0500, 0x0580))
    @Test fun comboIsKeyboard() = assertEquals(Cat.KEYBOARD, Classifier.categorize(0x0500, 0x05C0))
    @Test fun gamepadIsOther() = assertEquals(Cat.OTHER, Classifier.categorize(0x0500, 0x0508))
    @Test fun phoneIsOther() = assertEquals(Cat.OTHER, Classifier.categorize(0x0200, 0x020C))
}
