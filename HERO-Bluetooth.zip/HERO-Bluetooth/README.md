# HERO Bluetooth

تطبيق Android TV (Kotlin) يفحص Bluetooth الحقيقي في التلفزيون ويدير الأجهزة. المطوّر: HERO TONER

## البناء من الجوال عبر GitHub
1. أنشئ مستودعاً جديداً على GitHub.
2. فك ضغط الملف ثم ارفع محتوياته (Add file > Upload files).
3. مجلد `.github` مخفي في الجوال: أنشئ الملف يدوياً من Add file > Create new file باسم
   `.github/workflows/build-apk.yml` والصق محتواه.
4. تبويب Actions > Build APK > Run workflow.
5. بعد النجاح نزّل Artifact باسم `HERO-Bluetooth-APK` وفيه `app-debug.apk`.

## ما يفعله
- يفحص: Adapter، Manager، الخدمة، LE، الحالة، الصلاحيات، شاشة إعدادات النظام.
- لا يعرض نتائج وهمية، ولا يدّعي إضافة Bluetooth إن كان العتاد غائباً.
- بحث (كلاسيكي + BLE) وتصنيف: سماعات، مكبرات، لوحات مفاتيح، فأرة، واقتران عبر API الرسمي.
- لا يوجد Root ولا تعديل لملفات النظام.

## حدود Android
لا توجد واجهة رسمية لتطبيقات الطرف الثالث لوصل/فصل أجهزة مقترنة؛ النظام يتصل تلقائياً.
